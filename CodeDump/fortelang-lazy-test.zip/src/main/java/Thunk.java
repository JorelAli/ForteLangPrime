public interface Thunk<T> {
    T get();
}