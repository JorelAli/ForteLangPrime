import java.lang.reflect.Method;

public class TestDynamicAddOne {
    public static void main(String[] args) throws Exception {
        byte[] bytecode = AddOneFunctionGenerator.generateAddOneClass();

        DynamicClassLoader loader = new DynamicClassLoader();
        Class<?> addOneClass = loader.defineClass("AddOneFunction", bytecode);

        Method apply = addOneClass.getMethod("apply", Thunk.class);

        Thunk<Integer> lazyThree = new MemoThunk<>() {
            @Override
            protected Integer compute() {
                System.out.println("Evaluating lazyThree...");
                return 3;
            }
        };

        int result = (int) apply.invoke(null, lazyThree);
        System.out.println("Result: " + result);
        System.out.println("Second call result: " + lazyThree.get());
    }
}